package com.post.comment.postcommentapp.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class IndexPageController {

    @GetMapping("/")
    public String getApplicationEntryPage(Model model) {
        model.addAttribute("welcome", "Welcome to My Application, Enjoy!!!");
        return "index_page";
    }
}
