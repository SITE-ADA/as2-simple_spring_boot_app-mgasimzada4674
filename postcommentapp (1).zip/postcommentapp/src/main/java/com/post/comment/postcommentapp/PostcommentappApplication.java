package com.post.comment.postcommentapp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PostcommentappApplication {

    public static void main(String[] args) {
        SpringApplication.run(PostcommentappApplication.class, args);
    }

}
