package com.post.comment.postcommentapp.repository;

import com.post.comment.postcommentapp.entity.CommentEntity;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface CommentRepository extends CrudRepository<CommentEntity, Long> {


    List<CommentEntity> findByCommenter(String commenter);

    List<CommentEntity> findByCreatedAt(String createdAt);

    @Query(value = "select c from CommentEntity c where c.content like %:content%")
    List<CommentEntity> getSimilarCommentByContent(String content);

    @Query(value = "select c from CommentEntity c where c.replyCount = :replyCount")
    List<CommentEntity> getReplyCount(Long replyCount);

    @Query(value = "select *  from comments where reply_count = select max(reply_count) from comments", nativeQuery = true)
    CommentEntity getMaxRepliedComment();

    @Query(value = "select * from comments c where reply_count = select max(reply_count) from comments c where c.created_at = ?1 ", nativeQuery = true)
    CommentEntity getMaxRepliedCommentInGivenDay(String createdAt);
}
