package com.post.comment.postcommentapp.service;

import com.post.comment.postcommentapp.entity.PostEntity;
import com.post.comment.postcommentapp.repository.PostRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class PostService {

    @Autowired
    private PostRepository postRepository;

    public void create(PostEntity postEntity){
        postRepository.save(postEntity);
    }

    public void delete(Long postId){
        postRepository.deleteById(postId);
    }


    //When entity come with Id, it will be updated, if null, it will be created.
    public void update(PostEntity postEntity){
        create(postEntity);
    }

    public Iterable<PostEntity> readAll(){
        return postRepository.findAll();
    }

    public PostEntity readById(Long id){
        Optional<PostEntity> optionalById = postRepository.findById(id);
        return optionalById.orElse(null);
    }

    public List<PostEntity> findByAuthor(String author){
        return postRepository
                .findByAuthor(author);
    }

    public List<PostEntity> findByCreatedAt(String createdAt){
        return postRepository
                .findByCreatedAt(createdAt);
    }

    public List<PostEntity> getOverLikeCount(Long likeCount){
        return postRepository
                .getOverLikeCount(likeCount);
    }

    public List<PostEntity> getSimilarPostByContent(String content){
        return postRepository
                .getSimilarPostByContent(content);
    }

    public List<PostEntity> getReSharedCont(Long reSharedCount){
        return postRepository
                .getReSharedCont(reSharedCount);
    }

    public PostEntity getMaxLikedPostInGivenDay(String createdAt){
        return postRepository
                .getMaxLikedPostInGivenDay(createdAt);
    }

    public PostEntity getMaxLikedPost(){
        return postRepository.getMaxLikedPost();
    }

    public PostEntity getMaxReSharedPost(){
        return postRepository.getMaxReSharedPost();
    }


}
