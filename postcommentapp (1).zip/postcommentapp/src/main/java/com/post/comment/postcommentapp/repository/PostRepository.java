package com.post.comment.postcommentapp.repository;

import com.post.comment.postcommentapp.entity.PostEntity;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface PostRepository extends CrudRepository<PostEntity, Long> {


    List<PostEntity> findByAuthor(String author);

    List<PostEntity> findByCreatedAt(String createdAt);

    @Query(value = "select p from PostEntity p where p.likeCount > :likeCount")
    List<PostEntity> getOverLikeCount(Long likeCount);

    @Query(value = "select p from PostEntity p where p.content like %:content%")
    List<PostEntity> getSimilarPostByContent(String content);

    @Query(value = "select p from PostEntity p where p.reSharedCount = :reSharedCount")
    List<PostEntity> getReSharedCont(Long reSharedCount);

    @Query(value = "select *  from posts where like_count = select max(like_count) from posts ", nativeQuery = true)
    PostEntity getMaxLikedPost();

    @Query(value = "select *  from posts where re_shared_count = select max(re_shared_count) from posts ", nativeQuery = true)
    PostEntity getMaxReSharedPost();

    @Query(value = "select * from posts p where like_count =  select max(like_count) from posts where created_at =?1 ", nativeQuery = true)
    PostEntity getMaxLikedPostInGivenDay(String createdAt);


}
