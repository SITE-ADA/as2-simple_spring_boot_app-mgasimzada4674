package com.post.comment.postcommentapp.controller;

import com.post.comment.postcommentapp.entity.CommentEntity;
import com.post.comment.postcommentapp.service.CommentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.List;

@Controller
@RequestMapping("/comments/")
public class CommentController {

    @Autowired
    private CommentService commentService;

    @GetMapping("readAll")
    public String readAllComments(Model model) {
        Iterable<CommentEntity> comments = commentService.readAll();
        model.addAttribute("comments", comments);
        return "comment_list";
    }

    @GetMapping("fill")
    public String fillComments(Model model) {
        CommentEntity comment = new CommentEntity();
        model.addAttribute("comment", comment);
        return "comment_info";
    }

    @PostMapping("create")
    public String createComment(CommentEntity commentEntity, Model model) {
        commentService.create(commentEntity);
        Iterable<CommentEntity> comments = commentService.readAll();
        model.addAttribute("comments", comments);
        return "comment_list";
    }

    @GetMapping("refill/{id}")
    public String refillComments(@PathVariable Long id, Model model) {
        CommentEntity commentEntity = commentService.readById(id);
        model.addAttribute("comment", commentEntity);
        return "comment_info";
    }


    @GetMapping("delete/{id}")
    public String deletePost(@PathVariable Long id, Model model) {
        commentService.delete(id);
        Iterable<CommentEntity> comments = commentService.readAll();
        model.addAttribute("comments", comments);
        return "comment_list";
    }

    @GetMapping("commenter")
    public String findByCommenter(@RequestParam String commenter, Model model) {
        List<CommentEntity> comments = commentService.findByCommenter(commenter);
        model.addAttribute("comments", comments);
        return "comment_list";
    }

    @GetMapping("replyCount")
    public String findByReplyCount(@RequestParam Long replyCount, Model model) {
        List<CommentEntity> comments = commentService.getReplyCount(replyCount);
        model.addAttribute("comments", comments);
        return "comment_list";
    }

    @GetMapping("createdAt")
    public String findByCreatedAt(@RequestParam String createdAt, Model model) {
        List<CommentEntity> comments = commentService.findByCreatedAt(createdAt);
        model.addAttribute("comments", comments);
        return "comment_list";
    }

    @GetMapping("content")
    public String getSimilarCommentByContent(@RequestParam String content, Model model) {
        List<CommentEntity> comments = commentService.getSimilarCommentByContent(content);
        model.addAttribute("comments", comments);
        return "comment_list";
    }

    @GetMapping("maxrepliedcommentinday")
    public String getMaxRepliedCommentInGivenDay(@RequestParam String createdAt, Model model) {
        CommentEntity comment = commentService.getMaxRepliedCommentInGivenDay(createdAt);
        List<CommentEntity> comments = new ArrayList<>();
        comments.add(comment);
        model.addAttribute("comments", comments);
        return "comment_list";
    }

    @GetMapping("maxrepliedcomment")
    public String getMaxRepliedComment(Model model) {
        CommentEntity comment = commentService.getMaxRepliedComment();
        List<CommentEntity> comments = new ArrayList<>();
        comments.add(comment);
        model.addAttribute("comments", comments);
        return "comment_list";
    }

}
