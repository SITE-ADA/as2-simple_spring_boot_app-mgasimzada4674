package com.post.comment.postcommentapp.entity;


import javax.persistence.*;

@Entity
@Table(name = "comments")
public class CommentEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String content;

    private String createdAt;

    private String commenter;

    private Long replyCount;


    @ManyToOne
    @JoinColumn(name = "post_id", referencedColumnName = "id")
    private PostEntity post;

    public Long getId() {
        return id;
    }

    public CommentEntity setId(Long id) {
        this.id = id;
        return this;
    }

    public String getContent() {
        return content;
    }

    public CommentEntity setContent(String content) {
        this.content = content;
        return this;
    }

    public String getCreatedAt() {
        return createdAt;
    }

    public CommentEntity setCreatedAt(String createdAt) {
        this.createdAt = createdAt;
        return this;
    }

    public String getCommenter() {
        return commenter;
    }

    public CommentEntity setCommenter(String commenter) {
        this.commenter = commenter;
        return this;
    }

    public Long getReplyCount() {
        return replyCount;
    }

    public CommentEntity setReplyCount(Long replyCount) {
        this.replyCount = replyCount;
        return this;
    }

    public PostEntity getPost() {
        return post;
    }

    public CommentEntity setPost(PostEntity post) {
        this.post = post;
        return this;
    }
}
