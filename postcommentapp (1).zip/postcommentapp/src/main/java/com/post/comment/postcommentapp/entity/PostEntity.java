package com.post.comment.postcommentapp.entity;


import javax.persistence.*;
import java.util.List;

@Entity
@Table(name = "posts")
public class PostEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String author;

    private String content;

    private Long likeCount;

    private Long commentCount;

    private Long reSharedCount;

    private String createdAt;

    @OneToMany(mappedBy = "post")
    private List<CommentEntity> comments;


    public Long getId() {
        return id;
    }

    public PostEntity setId(Long id) {
        this.id = id;
        return this;
    }

    public String getAuthor() {
        return author;
    }

    public PostEntity setAuthor(String author) {
        this.author = author;
        return this;
    }

    public String getContent() {
        return content;
    }

    public PostEntity setContent(String content) {
        this.content = content;
        return this;
    }

    public Long getLikeCount() {
        return likeCount;
    }

    public PostEntity setLikeCount(Long likeCount) {
        this.likeCount = likeCount;
        return this;
    }

    public Long getCommentCount() {
        return commentCount;
    }

    public PostEntity setCommentCount(Long commentCount) {
        this.commentCount = commentCount;
        return this;
    }

    public Long getReSharedCount() {
        return reSharedCount;
    }

    public PostEntity setReSharedCount(Long reSharedCount) {
        this.reSharedCount = reSharedCount;
        return this;
    }

    public String getCreatedAt() {
        return createdAt;
    }

    public PostEntity setCreatedAt(String createdAt) {
        this.createdAt = createdAt;
        return this;
    }

    public List<CommentEntity> getComments() {
        return comments;
    }

    public PostEntity setComments(List<CommentEntity> comments) {
        this.comments = comments;
        return this;
    }
}
