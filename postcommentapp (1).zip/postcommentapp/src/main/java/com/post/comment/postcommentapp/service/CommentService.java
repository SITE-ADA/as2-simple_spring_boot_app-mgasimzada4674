package com.post.comment.postcommentapp.service;

import com.post.comment.postcommentapp.entity.CommentEntity;
import com.post.comment.postcommentapp.repository.CommentRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class CommentService {


    @Autowired
    private CommentRepository commentRepository;


    public void create(CommentEntity commentEntity) {
        commentRepository.save(commentEntity);
    }

    public void delete(Long postId) {
        commentRepository.deleteById(postId);
    }

    //When entity come with Id, it will be updated, if null, it will be created.
    public void update(CommentEntity commentEntity) {
        create(commentEntity);
    }

    public Iterable<CommentEntity> readAll() {
        return commentRepository.findAll();
    }

    public CommentEntity readById(Long id) {
        Optional<CommentEntity> optionalById = commentRepository.findById(id);
        return optionalById.orElse(null);
    }

    public List<CommentEntity> findByCommenter(String commenter) {
        return commentRepository
                .findByCommenter(commenter);
    }


    public List<CommentEntity> findByCreatedAt(String createdAt) {
        return commentRepository
                .findByCreatedAt(createdAt);
    }

    public List<CommentEntity> getSimilarCommentByContent(String content) {
        return commentRepository
                .getSimilarCommentByContent(content);
    }

    public List<CommentEntity> getReplyCount(Long replyCount) {
        return commentRepository
                .getReplyCount(replyCount);
    }

    public CommentEntity getMaxRepliedCommentInGivenDay(String createdAt) {
        return commentRepository
                .getMaxRepliedCommentInGivenDay(createdAt);
    }

    public CommentEntity getMaxRepliedComment() {
        return commentRepository
                .getMaxRepliedComment();
    }


}
