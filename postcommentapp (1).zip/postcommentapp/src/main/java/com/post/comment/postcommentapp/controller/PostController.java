package com.post.comment.postcommentapp.controller;

import com.post.comment.postcommentapp.entity.PostEntity;
import com.post.comment.postcommentapp.service.PostService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.List;

@Controller
@RequestMapping("/posts/")
public class PostController {

    @Autowired
    private PostService postService;

    @GetMapping("readAll")
    public String readAllPosts(Model model) {
        Iterable<PostEntity> posts = postService.readAll();
        model.addAttribute("posts", posts);
        return "post_list";
    }

    @GetMapping("fill")
    public String fillPosts(Model model){
        PostEntity post = new PostEntity();
        model.addAttribute("post",post);
        return "post_info";
    }
    @PostMapping("create")
    public String createPost(PostEntity postEntity, Model model){
        postService.create(postEntity);
        Iterable<PostEntity> posts = postService.readAll();
        model.addAttribute("posts", posts);
        return "post_list";
    }

    @GetMapping("refill/{id}")
    public String refillPosts(@PathVariable Long id, Model model){
        PostEntity postEntity = postService.readById(id);
        model.addAttribute("post",postEntity);
        return "post_info";
    }

    @GetMapping("delete/{id}")
    public String deletePost(@PathVariable Long id, Model model){
        postService.delete(id);
        Iterable<PostEntity> posts = postService.readAll();
        model.addAttribute("posts", posts);
        return "post_list";
    }

    @GetMapping("author")
    public String findByAuthor(@RequestParam String author, Model model){
        List<PostEntity> posts = postService.findByAuthor(author);
        model.addAttribute("posts",posts);
        return "post_list";
    }

    @GetMapping("createdAt")
    public String findByCreatedAt(@RequestParam String createdAt, Model model){
        List<PostEntity> posts = postService.findByCreatedAt(createdAt);
        model.addAttribute("posts",posts);
        return "post_list";
    }

    @GetMapping("likeCount")
    public String getOverLikeCount(@RequestParam Long likeCount, Model model){
        List<PostEntity> posts = postService.getOverLikeCount(likeCount);
        model.addAttribute("posts",posts);
        return "post_list";
    }

    @GetMapping("content")
    public String getSimilarPostByContent(@RequestParam String content, Model model){
        List<PostEntity> posts = postService.getSimilarPostByContent(content);
        model.addAttribute("posts",posts);
        return "post_list";
    }

    @GetMapping("sharedCount")
    public String getReSharedCont(@RequestParam Long sharedCount, Model model){
        List<PostEntity> posts = postService.getReSharedCont(sharedCount);
        model.addAttribute("posts",posts);
        return "post_list";
    }

    @GetMapping("maxlikedpostsinday")
    public String getMaxLikedPostInGivenDay(@RequestParam String createdAt, Model model){
        PostEntity post = postService.getMaxLikedPostInGivenDay(createdAt);
        List<PostEntity> posts = new ArrayList<>();
        posts.add(post);
        model.addAttribute("posts",posts);
        return "post_list";
    }

    @GetMapping("maxlikedposts")
    public String getMaxLikedPost(Model model){
        PostEntity post = postService.getMaxLikedPost();
        List<PostEntity> posts = new ArrayList<>();
        posts.add(post);
        model.addAttribute("posts",posts);
        return "post_list";
    }

    @GetMapping("maxresharedpost")
    public String getMaxReSharedPost(Model model){
        PostEntity post = postService.getMaxReSharedPost();
        List<PostEntity> posts = new ArrayList<>();
        posts.add(post);
        model.addAttribute("posts",posts);
        return "post_list";
    }
}
