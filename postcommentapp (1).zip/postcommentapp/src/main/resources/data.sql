

INSERT INTO Posts(author,content,like_count,comment_count,re_shared_count,created_at) VALUES ('Mark','Facebook is created',120000,5000,20,'01-01-2020')
INSERT INTO Posts(author,content,like_count,comment_count,re_shared_count,created_at) VALUES ('Steve','Apple is created',340000,3000,300,'13-12-2018')
INSERT INTO Posts(author,content,like_count,comment_count,re_shared_count,created_at) VALUES ('Bill','Microsoft is created',30000,23300,1000,'05-14-2010')
INSERT INTO Posts(author,content,like_count,comment_count,re_shared_count,created_at) VALUES ('Elon','Tesla is created',90000,4000,500,'01-01-2020')


INSERT INTO Comments(content,created_at,commenter,reply_count) VALUES ('Facebook is great platform','23-02-2015','TestUser1',20)
INSERT INTO Comments(content,created_at,commenter,reply_count) VALUES ('Apple is great company','03-05-2009','TestUser2',100)
INSERT INTO Comments(content,created_at,commenter,reply_count) VALUES ('Tesla is great company','23-02-2015','TestUser3',300)
